package com.vishu.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.vishu.Dao.addstudentDao;
import com.vishu.Model.addStudentmodel;
@WebServlet("/addstudent")
public class addStudent extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	doPost(req, resp);
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PrintWriter pw=resp.getWriter();
	
		String name=req.getParameter("name");
		String fname=req.getParameter("fname");
		String roll=req.getParameter("roll");
		String mobile=req.getParameter("mobile");
		String email=req.getParameter("email");
		String college=req.getParameter("college");
		
		addStudentmodel md=new addStudentmodel();
		md.setName(name);
		md.setFname(fname);
		md.setRoll(roll);
		md.setMobile(mobile);
		md.setEmail(email);
		md.setCollege(college);
		
		int i=addstudentDao.getstudent().insertresult(md);
		
		if(i >0) {
			pw.print("<h1 style=text-align:center>Success</h1>");
			req.getRequestDispatcher("AdminHome.jsp").include(req, resp);

		}else {
			pw.print("<h1 style=text-align:center>Failed</h1>");
			req.getRequestDispatcher("addstudent.jsp").include(req, resp);
			
		}
		
	}
	
}
