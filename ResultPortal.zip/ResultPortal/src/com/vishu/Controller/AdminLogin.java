package com.vishu.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet("/adminlogin")
public class AdminLogin extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	doPost(req, resp);
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	PrintWriter pw=resp.getWriter();
		String email=req.getParameter("email");
		String pass=req.getParameter("pass");
		
		
	if(email.equals("admin@gmail.com") && pass.equals("admin")) {
		
		HttpSession ss=req.getSession();
		ss.setAttribute("email", email);
		resp.getWriter().print("WELCOME" + email);
		
		
		
		pw.print("Logged In");
		resp.sendRedirect("AdminHome.jsp");
		
	}else {
		
			resp.getWriter().print("please login first");
			req.getRequestDispatcher("index.jsp").include(req, resp);
	}
		
	}
}

