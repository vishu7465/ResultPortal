package com.vishu.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.vishu.Model.ResultModel;

public class ResultDao {

	
	public static ResultDao result=new ResultDao();
	
	public static ResultDao getresult() {
		return result;
	}
	
	
	public int insertresult(ResultModel rs) {
		
		int i=0;
		try(Connection con=Dao.GetConnection()){
		PreparedStatement ps=con.prepareCall("insert into result values(?,?,?,?,?,?,?)");
		ps.setString(1, rs.getRoll());
		ps.setString(2, rs.getSub1());	
		ps.setString(3, rs.getSub2());
		ps.setString(4, rs.getSub3());
		ps.setString(5, rs.getSub4());
		ps.setString(6, rs.getSub5());
		ps.setString(7, rs.getSub6());
		
	 i=ps.executeUpdate();
		
		
	}catch(Exception e) {
		System.out.println(e);
	}
	
	
	
	
	return i;
	
	}
	
}
