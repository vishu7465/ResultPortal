package com.vishu.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.vishu.Dao.ResultDao;
import com.vishu.Model.ResultModel;
@WebServlet("/insertresult")
public class insertresult extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	doPost(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
		PrintWriter pw=resp.getWriter();
		
		String roll=req.getParameter("roll");
		String sub1=req.getParameter("sub1");
		String sub2=req.getParameter("sub2");
		String sub3=req.getParameter("sub3");
		String sub4=req.getParameter("sub4");
		String sub5=req.getParameter("sub5");
		String sub6=req.getParameter("sub6");
	
		
		ResultModel rm=new ResultModel();
		
		rm.setRoll(roll);
		rm.setSub1(sub1);
		rm.setSub2(sub2);
		rm.setSub3(sub3);
		rm.setSub4(sub4);
		rm.setSub5(sub5);
		rm.setSub6(sub6);
		
	int mr=ResultDao.getresult().insertresult(rm);
	
	if(mr>0) {
	
		req.setAttribute("rm", rm);
		
		
		pw.print("<h1 style=text-align:center>Result Updated</h1>");
req.getRequestDispatcher("AdminHome.jsp").include(req, resp);



	}else {
		pw.print("<h1 style=text-align:center>Failed update</h1>");
		req.getRequestDispatcher("Resultinsert.jsp").include(req, resp);
		
	}
	
	
	}
	
}
