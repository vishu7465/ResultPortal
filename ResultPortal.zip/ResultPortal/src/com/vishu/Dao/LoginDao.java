package com.vishu.Dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.sun.net.httpserver.Authenticator.Result;
import com.vishu.Model.registermodel;



public class LoginDao {

	public static LoginDao userdao= new LoginDao();
	public LoginDao() {
		
	}
	public static LoginDao GetUserdao() {
		return userdao;
	}
	
	public int insert(registermodel rm) {
		int i=0;
		try(Connection con=Dao.GetConnection()){
		PreparedStatement ps=con.prepareStatement("insert into register values(?,?,?,?,?)");
			ps.setString(1, rm.getName());
			ps.setString(2, rm.getFathername());
			ps.setString(3, rm.getMobile());
			ps.setString(4, rm.getEmail());
			ps.setString(5, rm.getPass());
		
			i=ps.executeUpdate();
		
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}
	
	public registermodel login(String email ,String pass) {
		
		registermodel rd=null;
		
		try (Connection con = Dao.GetConnection();) {
			PreparedStatement ps = con.prepareStatement("select * from register where email=? and pass=?");
			ps.setString(1, email);
			ps.setString(2, pass);
			
			
			ResultSet rs=ps.executeQuery();
			
			if(rs.next()) {
				rd=new registermodel();
				
				rd.setEmail(rs.getString(1));
				
				rd.setPass(rs.getString(2));
			}
			
	}catch(Exception e) {
		System.out.println(e);
	}
		return rd;
}
}