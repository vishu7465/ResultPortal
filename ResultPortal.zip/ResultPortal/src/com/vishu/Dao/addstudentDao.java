package com.vishu.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.vishu.Model.ResultModel;
import com.vishu.Model.addStudentmodel;

public class addstudentDao {
	public static addstudentDao studentDao=new addstudentDao();
	
	public static addstudentDao getstudent() {
		return studentDao;
	}
	
	
	public int insertresult(addStudentmodel rs) {
		
		int i=0;
		try(Connection con=Dao.GetConnection()){
		PreparedStatement ps=con.prepareCall("insert into newstudent values(?,?,?,?,?,?)");
		ps.setString(1, rs.getName());
		ps.setString(2, rs.getFname());
		ps.setString(3, rs.getRoll());
		ps.setString(4, rs.getMobile());
		ps.setString(5, rs.getEmail());
		ps.setString(6, rs.getCollege());
	 i=ps.executeUpdate();
		
		
	}catch(Exception e) {
		System.out.println(e);
	}
	
	
	
	
	return i;
	
	}

}
