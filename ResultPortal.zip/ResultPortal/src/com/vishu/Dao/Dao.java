package com.vishu.Dao;

import java.sql.Connection;

import java.sql.DriverManager;

import com.mysql.jdbc.Driver;

public class Dao {

	 static Connection con;
	
	 public static Connection GetConnection() {
	 
	try {
		
		Class.forName("com.mysql.jdbc.Driver");
		
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Exam", "root", "root");
		
	
		
	}catch(Exception e) {
		System.out.println(e);
	}
	return con;
	 
	 }
	 
}
